package Encapsulation;

public class Statickeyword {
	    static String collegeName = "GND University";
	    String name;
	    int rollNo;
	    Statickeyword(String name, int rollNo) {
	        this.name = name;
	        this.rollNo = rollNo;
	    }
	    void displayInfo() {
	        System.out.println("------------------------------");
	        System.out.println("College  " + collegeName);   
	        System.out.println("Name     " + name);           
	        System.out.println("Roll No  " + rollNo);         
	    }
	    public static void main(String[] args) {
	        Statickeyword s1 = new Statickeyword("Soni",  101);
	        Statickeyword  s2 = new Statickeyword("Moni",    102);
	        Statickeyword  s3 = new Statickeyword("joly", 103);
	        System.out.println(" Student Records");
	        s1.displayInfo();
	        s2.displayInfo();
	        s3.displayInfo();
	        System.out.println("\n  Changing college name ");
	        Statickeyword.collegeName = "Riverside College";
	        System.out.println("\n  After College Name Change ");
	        s1.displayInfo();
	        s2.displayInfo();
	        s3.displayInfo();
	    }
	}
