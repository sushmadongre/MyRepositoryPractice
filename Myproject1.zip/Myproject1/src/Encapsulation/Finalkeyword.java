package Encapsulation;
class Bank {
	 
    // ─── Final Variable ────────────────────
    // Cannot be changed once assigned
    final String IFSC = "BANK0001234";
 
    // ─── Normal Variable ───────────────────
    String bankName;
    String branch;
 
    // Constructor
    public Bank(String bankName, String branch) {
        this.bankName = bankName;
        this.branch   = branch;
    }
 
    // ─── Final Method ──────────────────────
    // Cannot be overridden by subclass
    public final void showIFSC() {
        System.out.println("---------------------------");
        System.out.println("  Bank Name : " + bankName);
        System.out.println("  Branch    : " + branch);
        System.out.println("  IFSC Code : " + IFSC);
        System.out.println("---------------------------");
    }
    public void showBankInfo() {
        System.out.println("  Bank Info  " + bankName + " - " + branch);
    }
}
class HDFCBank extends Bank {
    String accountType;
    public HDFCBank(String branch, String accountType) {
        super("HDFC Bank", branch);   // 
        this.accountType = accountType;
    }
    public void showBankInfo() {
        System.out.println("---------------------------");
        System.out.println("  HDFC Bank             ");
        System.out.println("  Branch        " + branch);
        System.out.println("  Account Type  " + accountType);
        System.out.println("---------------------------");
    }
}
public class Finalkeyword {
    public static void main(String[] args) {
        System.out.println("===========================");
        System.out.println("      FINAL KEYWORD DEMO   ");
        System.out.println("===========================\n");
        System.out.println("--- Bank Object ---");
        Bank bank = new Bank("State Bank", "MG Road");
        bank.showIFSC();        
        bank.showBankInfo();    
        System.out.println("\n--- HDFCBank Object ---");
        HDFCBank hdfc = new HDFCBank("Bidar", "Savings");
        hdfc.showIFSC();        
        hdfc.showBankInfo();    
        System.out.println("\n--- Final Variable Demo ---");
        System.out.println("  IFSC (Bank)  " + bank.IFSC);
        System.out.println("  IFSC (HDFCBank) " + hdfc.IFSC);
        System.out.println("\n===========================");
        System.out.println(" Final Keyword Rules    ");
        System.out.println("  final variable Cannot be changed");
        System.out.println("   final method  Cannot be overridden");
        System.out.println("  final class Cannot be extended");
        System.out.println("===========================");
    }
}

