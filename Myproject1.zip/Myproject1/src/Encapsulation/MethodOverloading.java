package Encapsulation;
class Calculator {
	 
    public int add(int a, int b) {
        return a + b;
    }
    public double add(double a, double b) {
        return a + b;
    }
}
public class MethodOverloading {
    public static void main(String[] args) {
        Calculator calc = new Calculator();
 
        System.out.println("===========================");
        System.out.println("     METHOD OVERLOADING    ");
        System.out.println("===========================\n");
        int result1 = calc.add(10, 20);
        System.out.println("--- add(int, int) ---");
        System.out.println("  add(10, 20)     = " + result1);
        double result2 = calc.add(10.5, 20.5);
        System.out.println("\n--- add(double, double) ---");
        System.out.println("  add(10.5, 20.5) = " + result2);
 
        System.out.println("\n===========================");
    }
}

