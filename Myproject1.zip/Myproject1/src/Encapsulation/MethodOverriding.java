package Encapsulation;
class Hospital {
	 
    void emergencyService() {
        System.out.println("Hospital Basic emergency services available 24/7");
        System.out.println("Hospital Ambulance helpline: 102");
    }
}
class CityHospital extends Hospital {
    void emergencyService() {
        super.emergencyService();
        System.out.println("CityHospital Advanced ICU and Trauma Care Unit available.");
        System.out.println("CityHospital Specialist doctors on-call round the clock.");
        System.out.println("CityHospital Emergency helpline: 1800-123-456");
    }
}
public class MethodOverriding {
 
    public static void main(String[] args) {
 
        System.out.println(" Method Overriding with super \n");
        System.out.println("Calling via Hospital object ");
        Hospital h = new Hospital();
        h.emergencyService();
        System.out.println();
        System.out.println("Calling via CityHospital object ");
        CityHospital ch = new CityHospital();
        ch.emergencyService();
        System.out.println();
        System.out.println("Upcasting (Hospital ref CityHospital object) ");
        Hospital ref = new CityHospital();   
        ref.emergencyService();            
    }
}
