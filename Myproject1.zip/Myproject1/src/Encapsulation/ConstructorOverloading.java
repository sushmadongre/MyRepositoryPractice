package Encapsulation;
class Product {
    private int productId;
    private String productName;
    private double price;
    public Product() {
        System.out.println("Product Created (Default Constructor)");
        productId   = 0;
        productName = "Unknown";
        price       = 0.0;
    }
    public Product(int productId, String productName, double price) {
        System.out.println("Product Created (Parameterized Constructor)");
        this.productId   = productId;
        this.productName = productName;
        this.price       = price;
    }
 
    public void displayProduct() {
        System.out.println("---------------------------");
        System.out.println("  Product ID   : " + productId);
        System.out.println("  Product Name : " + productName);
        System.out.println("  Price        : ₹" + price);
        System.out.println("---------------------------");
    }
}
public class ConstructorOverloading {
    public static void main(String[] args) {
 
        System.out.println("===========================");
        System.out.println("   CONSTRUCTOR OVERLOADING ");
        System.out.println("===========================\n");
        System.out.println("--- Object 1 (Default) ---");
        Product p1 = new Product();
        p1.displayProduct();
        System.out.println("\n--- Object 2 (Parameterized) ---");
        Product p2 = new Product(101, "Laptop", 85000.00);
        p2.displayProduct();
        System.out.println("\n--- Object 3 (Parameterized) ---");
        Product p3 = new Product(102, "Smartphone", 45000.00);
        p3.displayProduct();
    }
}
 
