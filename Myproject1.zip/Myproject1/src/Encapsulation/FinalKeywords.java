package Encapsulation;
class GovernmentRules {
    final int MAX_WORKING_HOURS = 8;
    void displayRules() {
        System.out.println("Rule :  Maximum working hours per day");
        System.out.println("Limit : " + MAX_WORKING_HOURS + " hours");
        System.out.println("Declared As : final int MAX_WORKING_HOURS = 8");
        System.out.println("Status : Protected by Government Law ");
    }
}
public class FinalKeywords {
    public static void main(String[] args) {
        System.out.println("Final Keywords");
        GovernmentRules rules = new GovernmentRules();
        System.out.println("Reading Final Variable");
        rules.displayRules();
        System.out.println();
        System.out.println("Compile-Time Restriction");
        System.out.println("The line below is intentionally commented out.");
        System.out.println("Uncommenting it causes a COMPILE-TIME ERROR");
        System.out.println("rules.MAX_WORKING_HOURS = 12;");
        System.out.println("ERROR → cannot assign a value to final variable MAX_WORKING_HOURS");
        System.out.println();
        System.out.println("Reading Value After Attempted Change");
        System.out.println("MAX_WORKING_HOURS = " + rules.MAX_WORKING_HOURS + "(unchanged—final holds its ground)");
                           
    }
}

