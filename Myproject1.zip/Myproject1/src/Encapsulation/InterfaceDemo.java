package Encapsulation;
interface Payment {
    void makePayment(double amount);
    default void paymentStatus() {
        System.out.println("Payment Processed Successfully");
    }
}
class UPI implements Payment {
    private String upiId;
    public UPI(String upiId) {
        this.upiId = upiId;
    }
    public void makePayment(double amount) {
        System.out.println("---------------------------");
        System.out.println("       UPI PAYMENT      ");
        System.out.println("---------------------------");
        System.out.println("  UPI ID : " + upiId);
        System.out.println("  Amount : ₹" + amount);
        paymentStatus();   
        System.out.println("---------------------------");
    }
}
class CreditCard implements Payment {
 
    private String cardNumber;
    private String cardHolder;
    public CreditCard(String cardNumber, String cardHolder) {
        this.cardNumber = cardNumber;
        this.cardHolder = cardHolder;
    }
    public void makePayment(double amount) {
        System.out.println("---------------------------");
        System.out.println("   CREDIT CARD PAYMENT   ");
        System.out.println("---------------------------");
        System.out.println("  Card Holder : " + cardHolder);
        System.out.println("  Card Number : 123445"+ cardNumber.substring(cardNumber.length() - 4));
        System.out.println("  Amount      : ₹" + amount);
        paymentStatus();   
        System.out.println("---------------------------");
    }
}
public class InterfaceDemo {
    public static void main(String[] args) {
 
        System.out.println("===========================");
        System.out.println("   INTERFACE IMPLEMENATION ");
        System.out.println("===========================\n");
        System.out.println("--- Payment via UPI ---");
        Payment payment1 = new UPI("Sudeep@upi");
        payment1.makePayment(2500.00);
        System.out.println("\n--- Payment via Credit Card ---");
        Payment payment2 = new CreditCard("987654", "Rahul");
        payment2.makePayment(5000.00);
        System.out.println("\n--- Processing Multiple Payments ---");
        Payment[] payments = {
            new UPI("Sushma@upi"),
            new CreditCard("1234576", "Sushma"),
        };
 
        for (Payment p : payments) {
            p.makePayment(8000.00);
            System.out.println();
        }
    }
}
