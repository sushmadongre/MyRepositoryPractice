package Encapsulation;
class Camera {
	 
    void capture() {
        System.out.println("  Camera     →  Capturing a standard photo.");
        System.out.println("  Camera     →  Resolution : 12 MP");
        System.out.println("  Camera     →  Mode       : Auto");
    }
}
class DSLCamera extends Camera {
    void capture() {
        System.out.println("Capturing a professional DSLR photo.");
        System.out.println("Resolution : 45 MP");
        System.out.println("Mode : Manual / RAW");
        System.out.println("Lens : 50mm f/1.8 Prime");
    }
}
class ActionCamera extends Camera {
    void capture() {
        System.out.println("ActionCam : Capturing high-speed action footage.");
        System.out.println("ActionCam : Resolution : 4K / 60fps");
        System.out.println("ActionCam : Mode       : Burst / Wide-angle");
    }
}
public class CameraPolymorphism {
    public static void main(String[] args) {
        System.out.println("Runtime Polymorphism Demo");
        System.out.println("Camera (Parent Object)");
        Camera cam = new Camera();
        cam.capture();
        System.out.println();
        System.out.println("DSLCamera (Child Object)");
        DSLCamera dsl = new DSLCamera();
        dsl.capture();
        System.out.println();
        System.out.println("Camera ref : DSLCamera object");
        Camera ref1 = new DSLCamera();    
        ref1.capture();                   
        System.out.println();
        System.out.println(" Camera ref : ActionCamera object");
        Camera ref2 = new ActionCamera();  
        ref2.capture();                    
        System.out.println();
        System.out.println("Polymorphism via Camera Array");
        Camera[] cameras = {
            new Camera(),
            new DSLCamera(),
            new ActionCamera()
        };
 
        for (Camera c : cameras) {
            c.capture();              
            System.out.println();
        }
    }
}
 

