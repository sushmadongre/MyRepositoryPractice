package Encapsulation;
class Engine {
    String engineType;
    int    horsepower;
    double displacement;
    Engine(String engineType, int horsepower, double displacement) {
        this.engineType   = engineType;
        this.horsepower   = horsepower;
        this.displacement = displacement;
    }
    void engineInfo() {
        System.out.println("Engine Type : " + engineType);
        System.out.println("Horsepower : " + horsepower + " HP");
        System.out.println("Displacement : " + displacement + " cc");
    }
}
class Car {
    String carName;
    String brand;
    int    year;
    Engine engine;         
    Car(String carName, String brand,int year,Engine engine) {
        this.carName = carName;
        this.brand   = brand;
        this.year    = year;
        this.engine  = engine;  
    }
    void carInfo() {
        System.out.println("Car Name : " + carName);
        System.out.println("Brand :" + brand);
        System.out.println("Year :" + year);
        System.out.println("Engine Details");
        engine.engineInfo();   
    }
}
public class CarAggregation {
    public static void main(String[] args) {
        System.out.println("Aggregation Demo : Car Has-A Engine");
        Engine e1 = new Engine("V6 Petrol",280,2995);
        Engine e2 = new Engine("Inline-4 Diesel",190,1997);
        Car car1 = new Car("Mustang GT","Ford",2023,e1);
        Car car2 = new Car("Fortuner",    "Toyota", 2024, e2);
        System.out.println("Car 1");
        car1.carInfo();
        System.out.println();
        System.out.println(" Car 2");
        car2.carInfo();
        System.out.println();
        System.out.println("Engine used independently (without Car)");
        e1.engineInfo();
    }
}

