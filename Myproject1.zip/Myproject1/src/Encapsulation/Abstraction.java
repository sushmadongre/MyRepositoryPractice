package Encapsulation;
abstract class Animal {
    public abstract void sound();
    public void eat() {
        System.out.println("This animal eats food ");
    }
 
    public void sleep() {
        System.out.println("This animal sleeps ");
    }
}
class Dog extends Animal {
    public void sound() {
        System.out.println("Dog says: Woof Woof ");
    }
}
class Cat extends Animal {
    public void sound() {
        System.out.println("Cat says: Meow Meow ");
    }
}
public class Abstraction{
    public static void main(String[] args) {
 
        System.out.println("===========================");
        System.out.println("  ABSTRACTION — ABSTRACT   ");
        System.out.println("        CLASS DEMO         ");
        System.out.println("===========================\n");
        System.out.println("--- Dog ---");
        Dog dog = new Dog();
        dog.sound();     
        dog.eat();       
        dog.sleep();  
        System.out.println("\n--- Cat ---");
        Cat cat = new Cat();
        cat.sound();     
        cat.eat();    
        cat.sleep();     
 
        System.out.println("\n--- Using Abstract Class Reference ---");
        Animal a1 = new Dog();    
        Animal a2 = new Cat();   
        a1.sound();               
        a2.sound();               
    }
}
 

