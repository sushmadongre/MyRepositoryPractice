package Encapsulation;

public class Account {
	    private String accountHolderName;
	    private double balance;
	    public void setAccountHolderName(String name) {
	        accountHolderName = name;
	    }
	    public void setBalance(double amount) {
	        if (amount < 0) {
	            System.out.println("Balance cannot be negative Value rejected");
	        } else {
	            balance = amount;
	            System.out.println("Balance updated successfully");
	        }
	    }
	    public String getAccountHolderName() {
	        return accountHolderName;
	    }
	    public double getBalance() {
	        return balance;
	    }
	    public void displayAccount() {
	        System.out.println("-------------");
	        System.out.println("Account Holder " + accountHolderName);
	        System.out.println("Balance" + balance);
	        System.out.println("----------------");
	    }
	    public static void main(String[] args) {
	        Account acc = new Account();
	        acc.setAccountHolderName("Sushma");
	        acc.setBalance(10000);
	 
	        System.out.println("\n-- Account Details ");
	        acc.displayAccount();
	        System.out.println("Attempting to set negative balance");
	        acc.setBalance(-2000);  
	        System.out.println("\n--- Account Details After Invalid Update ---");
	        acc.displayAccount();
	        acc.setBalance(75000); 
	        System.out.println("\n--- Final Account Details ---");
	        acc.displayAccount();
	    }
	}
	 
