package Encapsulation;
class Person {
	 
    String name;
    int age;
    public Person(String name, int age) {
        this.name = name;
        this.age  = age;
        System.out.println(" Person Created!");
        System.out.println(" Name : " + name);
        System.out.println(" Age  : " + age);
    }
    public void displayPerson() {
        System.out.println("-------------");
        System.out.println("  Name : " + name);
        System.out.println("  Age  : " + age);
    }
}
class Student extends Person {
 
    int rollNo;
    String course;
    public Student(String name, int age, int rollNo, String course) {
        super(name, age);
        this.rollNo = rollNo;
        this.course = course;
        System.out.println("Student Created!");
        System.out.println("   Roll No : " + rollNo);
        System.out.println("   Course  : " + course);
    }
    public void displayStudent() {
        displayPerson();           
        System.out.println("  Roll No : " + rollNo);
        System.out.println("  Course  : " + course);
        System.out.println("---------------------------");
    }
    public void showInfo() {
        System.out.println("\n--- Using super to access Parent ---");
        System.out.println("  Parent Name : " + super.name);   
        System.out.println("  Parent Age  : " + super.age);    
        System.out.println("  Student Roll: " + rollNo);
    }
}
public class Superkeyword {
    public static void main(String[] args) {
 
        System.out.println("===========================");
        System.out.println("    USE OF SUPER KEYWORD   ");
        System.out.println("===========================\n");
        System.out.println("--- Creating Student Object ---\n");
        Student s = new Student("Viraj", 50, 201, "B.Tech");
        System.out.println("\n--- Student Full Details ---");
        s.displayStudent();
        s.showInfo();
 
        System.out.println("\n======================");
        System.out.println("  Order of Execution:      ");
        System.out.println("  1️ Person Constructor    ");
        System.out.println("  2️  Student Constructor   ");
        System.out.println("========================");
    }
}
 
