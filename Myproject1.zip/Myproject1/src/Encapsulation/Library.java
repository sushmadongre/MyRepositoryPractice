package Encapsulation;

public class Library {
	    String libraryName;
	    Library() {
	        System.out.println("Welcome to the Library");
	    }
	    void showLocation() {
	        System.out.println("This library is located in Bidar");
	    }
	 
	    public static void main(String[] args) {
	        Library lib = new Library();
	        lib.libraryName = "Central Public Library";
	        System.out.println("Library Name " + lib.libraryName);
	        lib.showLocation();
	    }
	}

