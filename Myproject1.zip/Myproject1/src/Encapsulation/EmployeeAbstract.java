package Encapsulation;
abstract class Employee {
    String name;
    int    employeeId;
    Employee(String name, int employeeId) {
        this.name       = name;
        this.employeeId = employeeId;
    }
    abstract double calculateSalary();
    void employeeDetails() {
        System.out.println("---");
        System.out.println("Employee ID : " + employeeId);
        System.out.println("Employee Name : " + name);
        System.out.println("Salary  : " + calculateSalary());
        System.out.println("---");
    }
}
class FullTimeEmployee extends Employee {
    double monthlySalary;
    FullTimeEmployee(String name, int employeeId, double monthlySalary) {
        super(name, employeeId);
        this.monthlySalary = monthlySalary;
    }
    double calculateSalary() {
        return monthlySalary; 
    }
    void employeeDetails() {
        System.out.println("Type : Full-Time Employee");
        super.employeeDetails();
    }
}
class PartTimeEmployee extends Employee {
    int    hoursWorked;
    double hourlyRate;
    PartTimeEmployee(String name, int employeeId, int hoursWorked, double hourlyRate) {
        super(name, employeeId);
        this.hoursWorked = hoursWorked;
        this.hourlyRate  = hourlyRate;
    }
    double calculateSalary() {
        return hoursWorked * hourlyRate;  
    }
    void employeeDetails() {
        System.out.println("Type : Part-Time Employee");
        System.out.println("Hours Worked : " + hoursWorked);
        System.out.println("Hourly Rate   : " + hourlyRate);
        super.employeeDetails();
    }
}
public class EmployeeAbstract {
    public static void main(String[] args) {
        System.out.println("Abstract Class Employee");
        FullTimeEmployee fte = new FullTimeEmployee("Riya",101,750);
        fte.employeeDetails();
        System.out.println();
        PartTimeEmployee pte = new PartTimeEmployee("Arjun",102,120,250);
        pte.employeeDetails();
        System.out.println();
        System.out.println("Upcasting Demo");
        Employee e1 = new FullTimeEmployee("Soniya",103,900);
        Employee e2 = new PartTimeEmployee("Kabir",104,80,130);
 
        e1.employeeDetails();
        System.out.println();
        e2.employeeDetails();
    }
}

