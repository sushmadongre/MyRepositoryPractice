package Encapsulation;
class Vehicle {
    public void fuelType() {
        System.out.println("Vehicle runs on Fuel ");
    }
 
    public void display() {
        System.out.println("This is a Vehicle ");
    }
}
class ElectricCar extends Vehicle{
    public void fuelType() {
        System.out.println("Electric Car runs on Electricity ⚡");
    }
 
    public void chargingTime() {
        System.out.println("Charging Time: 2 Hours ");
    }
}
public class Inheritance {
    public static void main(String[] args) {
        System.out.println("===========================");
        System.out.println("       VEHICLE OBJECT      ");
        System.out.println("===========================");
        Vehicle vehicle = new Vehicle();
        vehicle.display();           
        vehicle.fuelType();          
        System.out.println("\n===========================");
        System.out.println("     ELECTRIC CAR OBJECT   ");
        System.out.println("===========================");
        ElectricCar electricCar = new ElectricCar();
        electricCar.display();       
        electricCar.fuelType();      
        electricCar.chargingTime();  
        System.out.println("\n===========================");
        System.out.println("       POLYMORPHISM        ");
        System.out.println("===========================");
        Vehicle v = new ElectricCar();   
        v.fuelType();                    
        System.out.println("(Parent reference calls overridden method)");
    }
}
