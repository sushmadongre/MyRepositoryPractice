package Encapsulation;
class University {
    static String country = "India";
    String universityName;
    University(String universityName) {
        this.universityName = universityName;
    }
    void displayInfo() {
        System.out.println("---");
        System.out.println("University : " + universityName);
        System.out.println("Country : " + country);           
        System.out.println("---");
    }
}
public class UniversityStatic {
    public static void main(String[] args) {
        System.out.println("Static Variable Demo");
        University u1 = new University("IIT Bombay");
        University u2 = new University("Delhi University");
        University u3 = new University("Anna University");
        System.out.println("Initial Values");
        u1.displayInfo();
        u2.displayInfo();
        u3.displayInfo();
        System.out.println("Changing country to \"Australia\" via University.country ");
        University.country = "Australia";
        System.out.println("After Static Variable Change");
        u1.displayInfo();   
        u2.displayInfo();
        u3.displayInfo();
        System.out.println("University.country = "+ University.country);
    }
}

