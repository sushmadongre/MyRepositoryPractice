package Encapsulation;

	class Course {
		 
	    void courseInfo() {
	        System.out.println("Course: This is a University Course.");
	    }
	}
	class Science extends Course {
	 
	    void scienceInfo() {
	        System.out.println("Science Subjects: Physics, Chemistry, Biology, Maths");
	    }
	}
	class Commerce extends Course {
	 
	    void commerceInfo() {
	        System.out.println("Commerce Subjects: Accounts,Economics,Business Studies");
	    }
	}
	class Arts extends Course {
	 
	    void artsInfo() {
	        System.out.println("Arts Subjects: History,Geography,Political Science");
	    }
	}
	public class Hierarchicalinheritance{
	    public static void main(String[] args) {
	 
	        System.out.println(" Hierarchical Inheritance Demo\n");
	        Science sc = new Science();
	        System.out.println(" Science Stream ");
	        sc.courseInfo();      
	        sc.scienceInfo();     
	        Commerce co = new Commerce();
	        System.out.println("\n Commerce Stream ");
	        co.courseInfo();       
	        co.commerceInfo();     
	        Arts ar = new Arts();
	        System.out.println("\n Arts Stream ");
	        ar.courseInfo();       
	        ar.artsInfo();         
	 
	        System.out.println("\n Inheritance Hierarchy ");
	        System.out.println("      Course ");
	        System.out.println("  Science      ");
	        System.out.println(" SCommerce Arts  ");
	    }
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
