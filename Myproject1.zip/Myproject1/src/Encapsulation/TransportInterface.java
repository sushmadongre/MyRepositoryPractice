package Encapsulation;
	interface Transport {
	    void booking();
	}
	class Bus implements Transport {
	    public void booking() {
	        System.out.println("Mode : Bus");
	        System.out.println("Route : Mumbai to Pune");
	        System.out.println("Seat Type :  Sleeper");
	        System.out.println("Fare :350 per person");
	        System.out.println("Status : Booking Confirmed ");
	    }
	}
	class Flight implements Transport {
	    public void booking() {
	        System.out.println("Mode : Flight");
	        System.out.println("Route : Delhi to Bangalore");
	        System.out.println("Seat Type : Economy / Business");
	        System.out.println("Fare : 4,500 per person");
	        System.out.println("Status : Booking Confirmed");
	    }
	}
	public class TransportInterface {
	    public static void main(String[] args) {
	        System.out.println("Transport Booking System");
	        System.out.println(" Bus Booking ");
	        Transport t1 = new Bus();
	        t1.booking();
	        System.out.println();
	        System.out.println("Flight Booking");
	        Transport t2 = new Flight();
	        t2.booking();
	        System.out.println();
	        System.out.println("Runtime Switch (same reference)");
	        Transport t3;
	        t3 = new Bus();
	        System.out.println("t3 now points to Bus");
	        t3.booking();
	        System.out.println();
	        t3 = new Flight();
	        System.out.println("t3 now points to Flight:");
	        t3.booking();
	    }
	}
	 

