package Encapsulation;
class LoanCalculator {
    void calculateLoan(int amount) {
        double defaultRate = 8.5;
        double interest    = (amount * defaultRate) / 100;
        double totalPayable = amount + interest;
 
        System.out.println("--- Loan Details (Default Interest Rate) ---");
        System.out.println("Loan Amount  : ₹" + amount);
        System.out.println("Interest Rate : " + defaultRate + "% (default)");
        System.out.println("Interest Amount : ₹" + interest);
        System.out.println("Total Payable : ₹" + totalPayable);
    }
    void calculateLoan(int amount, double interestRate) {
        double interest      = (amount * interestRate) / 100;
        double totalPayable  = amount + interest;
 
        System.out.println("--- Loan Details (Custom Interest Rate) ---");
        System.out.println("Loan Amount      : ₹" + amount);
        System.out.println("Interest Rate    : " + interestRate + "%");
        System.out.println("Interest Amount  : ₹" + interest);
        System.out.println("Total Payable    : ₹" + totalPayable);
    }
}
public class LoancalculatorMain  {
	 public static void main(String[] args) {
		 
	        LoanCalculator lc = new LoanCalculator();
	 
	        System.out.println("Bank Loan Calculator \n");
	        lc.calculateLoan(100000);
	 
	        System.out.println();
	        lc.calculateLoan(10000, 10.5);
	    }
	}

