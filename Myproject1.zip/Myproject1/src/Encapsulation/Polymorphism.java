package Encapsulation;
class Shape {
    public void area() {
        System.out.println("Calculating area of a Shape...");
    }
    public void display() {
        System.out.println("This is a Shape ");
    }
}
 

class Rectangle extends Shape {
 
    double length;
    double width;
    public Rectangle(double length, double width) {
        this.length = length;
        this.width  = width;
    }
    public void area() {
        double area = length * width;
        System.out.println("---------------------------");
        System.out.println("  Shape   : Rectangle  ");
        System.out.println("  Length  : " + length);
        System.out.println("  Width   : " + width);
        System.out.println("  Formula : length × width");
        System.out.println("  Area    : " + area);
        System.out.println("---------------------------");
    }
}
class Circle extends Shape {
 
    double radius;
    public Circle(double radius) {
        this.radius = radius;
    }
    public void area() {
        double area = Math.PI * radius * radius;
        System.out.println("---------------------------");
        System.out.println("  Shape   : Circle      ");
        System.out.println("  Radius  : " + radius);
        System.out.println("  Formula : π × r²        ");
        System.out.printf("  Area    : %.2f%n", area);
        System.out.println("---------------------------");
    }
}
class Triangle extends Shape {
 
    double base;
    double height;
    public Triangle(double base, double height) {
        this.base   = base;
        this.height = height;
    }
    public void area() {
        double area = 0.5 * base * height;
        System.out.println("---------------------------");
        System.out.println("  Shape   : Triangle   ");
        System.out.println("  Base    : " + base);
        System.out.println("  Height  : " + height);
        System.out.println("  Formula : ½ × base × height");
        System.out.println("  Area    : " + area);
        System.out.println("---------------------------");
    }
}
public class Polymorphism {
    public static void main(String[] args) {
 
        System.out.println("===========================");
        System.out.println("  POLYMORPHISM   ");
        System.out.println("        BINDING            ");
        System.out.println("===========================\n");
        Shape shape;   
        System.out.println("--- Shape ref → Rectangle ---");
        shape = new Rectangle(2, 3);    
        shape.area();                    
        System.out.println("\n--- Shape ref → Circle ---");
        shape = new Circle(5);           
        shape.area();                    
        System.out.println("\n--- Shape ref → Triangle ---");
        shape = new Triangle(6, 8);     
        shape.area();                    
        System.out.println("\n--- Polymorphism with Array ---");
        Shape[] shapes = {
            new Rectangle(10, 4),
            new Circle(5),
            new Triangle(7, 3)
        };
 
        for (Shape s : shapes) {
            s.area();    
            System.out.println();
        }
    }
}
 
