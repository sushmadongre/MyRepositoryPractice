package Encapsulation;
class School {
    String name;
    School() {
        name = "St. Xavier's School";
        System.out.println("School Name:" + name);
    }
    void showLocation() {
        System.out.println("This School is based out of Kolkata");
    }
}
public class SchoolMain {
    public static void main(String[] args) {
        System.out.println("School Information");
        School sc = new School();
        System.out.println();
        sc.showLocation();
        System.out.println();
        System.out.println("");
    }
}

