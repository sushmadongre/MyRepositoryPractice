package looping;
import java.util.Scanner;
public class PrintNumber1toN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner sc = new Scanner(System.in);
		 
	        System.out.print("Enter the value of N: ");
	        int n = sc.nextInt();
	 
	        System.out.print("Output: ");
	        for (int i = 1; i <= n; i++) {
	            System.out.print(i + " ");
	        }
	        System.out.println();
	 
	        sc.close();
	    }
	}
	 
	


