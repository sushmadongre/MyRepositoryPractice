package looping;
import java.util.Scanner;
public class PalingromNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner sc = new Scanner(System.in);
		 
	        System.out.print("Enter a number: ");
	        int num = sc.nextInt();
	 
	        int original = num;
	        int reversed = 0;
	 
	        while (num != 0) {
	            int lastDigit = num % 10;              
	            reversed = reversed * 10 + lastDigit;  
	            num = num / 10;                        
	        }
	 
	        System.out.println("Original Number : " + original);
	        System.out.println("Reversed Number : " + reversed);
	 
	        if (original == reversed) {
	            System.out.println(original + " is a Palindrome ✅");
	        } else {
	            System.out.println(original + " is Not a Palindrome ❌");
	        }
	 
	        sc.close();
	    }
	
	}


