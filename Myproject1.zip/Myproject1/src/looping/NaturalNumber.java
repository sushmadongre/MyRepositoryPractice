package looping;
import java.util.Scanner;
public class NaturalNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		 
        System.out.print("Enter the value of N: ");
        int n = sc.nextInt();
 
        int i = 1;
        int sum = 0;
 
        while (i <= n) {
            sum = sum + i;
            i++;
        }
 
        System.out.println("Sum of first " + n + " natural numbers = " + sum);
 
        sc.close();
	}

}
