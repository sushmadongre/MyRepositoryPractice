package looping;
import java.util.Scanner;
public class Countdigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner sc = new Scanner(System.in);
		 
	        System.out.print("Enter a number: ");
	        int num = sc.nextInt();
	 
	        int original = num;
	        int count = 0;
	 
	        while (num != 0) {
	            num = num / 10;   
	            count++;         
	        }
	 
	        System.out.println("Number         : " + original);
	        System.out.println("Number of Digits: " + count);
	 
	        sc.close();
	}

}
