package looping;
import java.util.Scanner;
public class FactorialNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  Scanner sc = new Scanner(System.in);
		  
	        System.out.print("Enter a number: ");
	        int num = sc.nextInt();
	 
	        long factorial = 1;
	 
	        for (int i = 1; i <= num; i++) {
	            factorial = factorial * i;   
	        }
	 
	        System.out.println("Factorial of " + num + " = " + factorial);
	 
	        sc.close();
	}

}
