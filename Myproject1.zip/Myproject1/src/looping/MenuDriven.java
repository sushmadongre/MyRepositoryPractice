package looping;
import java.util.Scanner;

public class MenuDriven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  Scanner sc = new Scanner(System.in);
		  
	        int choice;
	 
	        do {
	            // Display Menu
	            System.out.println("\n===========================");
	            System.out.println("      CALCULATOR MENU      ");
	            System.out.println("===========================");
	            System.out.println("  1. Add");
	            System.out.println("  2. Subtract");
	            System.out.println("  3. Multiply");
	            System.out.println("  4. Divide");
	            System.out.println("  5. Exit");
	            System.out.println("===========================");
	            System.out.print("Enter your choice (1-5): ");
	            choice = sc.nextInt();
	 
	            if (choice >= 1 && choice <= 4) {
	 
	                System.out.print("Enter first number  : ");
	                double num1 = sc.nextDouble();
	                System.out.print("Enter second number : ");
	                double num2 = sc.nextDouble();
	 
	                switch (choice) {
	 
	                    case 1:
	                        double sum = num1 + num2;
	                        System.out.println("Result: " + num1 + " + " + num2 + " = " + sum);
	                        break;
	 
	                    case 2:
	                        double diff = num1 - num2;
	                        System.out.println("Result: " + num1 + " - " + num2 + " = " + diff);
	                        break;
	 
	                    case 3:
	                        double product = num1 * num2;
	                        System.out.println("Result: " + num1 + " x " + num2 + " = " + product);
	                        break;
	 
	                    case 4:
	                        if (num2 != 0) {
	                            double division = num1 / num2;
	                            System.out.println("Result: " + num1 + " / " + num2 + " = " + division);
	                        } else {
	                            System.out.println(" Division by Zero is not allowed!");
	                        }
	                        break;
	                }
	 
	            } else if (choice == 5) {
	                System.out.println("\n===========================");
	                System.out.println("  Exiting Calculator...    ");
	                System.out.println("  Thank You!    ");
	                System.out.println("=====================");
	            } else {
	                System.out.println(" Invalid Choice! Please enter between 1 to 5.");
	            }
	 
	        } while (choice != 5);  
	 
	        sc.close();
	    }
	}


