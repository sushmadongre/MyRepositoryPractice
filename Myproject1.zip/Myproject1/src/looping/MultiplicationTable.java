package looping;
import java.util.Scanner;
public class MultiplicationTable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner sc = new Scanner(System.in);
		 
	        System.out.print("Enter a number: ");
	        int num = sc.nextInt();
	 
	        System.out.println("\nMultiplication Table of " + num + ":");
	        System.out.println("-------------------");
	 
	        for (int i = 1; i <= 10; i++) {
	            System.out.println(num + " x " + i + " = " + (num * i));
	        }
	 
	        System.out.println("-------------------");
	 
	        sc.close();
	    }
	}


